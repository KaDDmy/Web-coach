from flask import Flask, render_template, request, redirect, session, jsonify
from flask_restful import Api, Resource
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
import random

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Секретный ключ для сессий
api = Api(app)


def get_db_connection():
    conn = sqlite3.connect('db.db')
    conn.row_factory = sqlite3.Row
    return conn


@app.route('/')
def index():
    return render_template('index.html', user=session.get('user'))


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        login = request.form['login']
        password = generate_password_hash(request.form['password'])
        conn = get_db_connection()

        # Получаем все id тренажеров
        machine_ids = conn.execute('SELECT id FROM machines').fetchall()
        machine_ids = [str(m['id']) for m in machine_ids]
        machines_string = ','.join(machine_ids)

        try:
            # Добавляем пользователя с заполнением поля machines и типа тренировки (по умолчанию "фулбади")
            conn.execute('INSERT INTO users (login, password, type, machines) VALUES (?, ?, ?, ?)',
                         (login, password, 'фулбади', machines_string))
            conn.commit()
        except sqlite3.IntegrityError:
            conn.close()
            return 'Login already taken!'

        conn.close()
        return redirect('/login')
    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        login = request.form['login']
        password = request.form['password']
        conn = get_db_connection()
        user = conn.execute('SELECT * FROM users WHERE login = ?', (login,)).fetchone()
        conn.close()
        if user and check_password_hash(user['password'], password):
            session['user'] = dict(user)
            return redirect('/')
        else:
            return 'Invalid login or password!'
    return render_template('login.html')


@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect('/')


@app.route('/profile', methods=['GET', 'POST'])
def profile():
    if 'user' not in session:
        return redirect('/login')

    conn = get_db_connection()
    machines = conn.execute('SELECT * FROM machines').fetchall()

    if request.method == 'POST':
        workout_type = request.form['type']
        selected_machines = request.form.getlist('machines')
        machines_str = ','.join(selected_machines)

        conn.execute('UPDATE users SET type = ?, machines = ? WHERE id = ?',
                     (workout_type, machines_str, session['user']['id']))
        conn.commit()

        # Получить обновлённые данные пользователя
        updated_user = conn.execute('SELECT * FROM users WHERE id = ?', (session['user']['id'],)).fetchone()
        session['user'] = dict(updated_user)

    conn.close()
    return render_template('profile.html', user=session['user'], machines=machines)


@app.route('/generate', methods=['GET', 'POST'])
def generate():
    if 'user' not in session:
        return redirect('/login')

    conn = get_db_connection()
    machines_str = session['user'].get('machines', '')
    machines = [m.strip() for m in machines_str.split(',') if m.strip().isdigit()]
    user_type = session['user'].get('type')
    muscle_groups = ['Ноги', 'Спина', 'Грудь', 'Бицепс', 'Трицепс', 'Плечи', 'Предплечья', 'Пресс', 'Трапеции']

    def get_exercises_for_muscle(muscle, limit):
        if machines:
            placeholders = ','.join(['?'] * len(machines))
            query = f'''
                SELECT * FROM exercises
                WHERE description = ? AND (free = 1 OR machine_id IN ({placeholders}))
            '''
            params = [muscle] + machines
        else:
            query = '''
                SELECT * FROM exercises
                WHERE description = ? AND free = 1
            '''
            params = [muscle]

        results = conn.execute(query, params).fetchall()
        return random.sample(results, min(len(results), limit)) if results else []

    if request.method == 'POST':
        exercises = []

        if user_type == 'фулбади':
            for muscle in muscle_groups:
                exercises += get_exercises_for_muscle(muscle, 2)

        elif user_type == 'сплит':
            selected_muscles = [key for key in request.form.keys() if
                                key in muscle_groups and request.form.get(key) == 'on']
            count = len(selected_muscles)

            if count == 0:
                conn.close()
                return render_template('generate.html', exercises=[], user=session.get('user'),
                                       message="Выберите хотя бы одну группу мышц.")

            base_limit = max(int(9 / count), 1)
            if count == 1:
                base_limit = max(base_limit - 2, 1)
            elif count > 4:
                base_limit += 1

            for muscle in selected_muscles:
                exercises += get_exercises_for_muscle(muscle, base_limit)

        conn.close()

        for i in range(len(exercises)):
            exercises[i] = dict(exercises[i])
            exercises[i]['name'] = f"{exercises[i]['name']} ({exercises[i]['technique']})"

        return render_template('generate.html', exercises=exercises, user=session.get('user'))

    if user_type == 'сплит':
        return render_template('difficulty.html', user=session.get('user'), muscle_groups=muscle_groups)
    else:
        exercises = []
        for muscle in muscle_groups:
            exercises += get_exercises_for_muscle(muscle, 2)

        conn.close()

        for i in range(len(exercises)):
            exercises[i] = dict(exercises[i])
            exercises[i]['name'] = f"{exercises[i]['name']} ({exercises[i]['technique']})"

        return render_template('generate.html', exercises=exercises, user=session.get('user'))


class Users(Resource):
    def get(self):
        conn = get_db_connection()
        users = conn.execute('SELECT id, login, type, machines FROM users').fetchall()
        conn.close()
        return jsonify([dict(user) for user in users])


class UserByID(Resource):
    def get(self, user_id):
        conn = get_db_connection()
        user = conn.execute('SELECT id, login, type, machines FROM users WHERE id = ?', (user_id,)).fetchone()
        conn.close()
        if user:
            return jsonify(dict(user))
        return {'message': 'User not found'}, 404


class RegisterUser(Resource):
    def post(self):
        data = request.get_json()
        login = data.get('login')
        password = data.get('password')

        if not login or not password:
            return {'message': 'Login and password required'}, 400

        hashed_password = generate_password_hash(password)
        conn = get_db_connection()

        machine_ids = conn.execute('SELECT id FROM machines').fetchall()
        machine_str = ','.join(str(m['id']) for m in machine_ids)

        try:
            conn.execute('INSERT INTO users (login, password, type, machines) VALUES (?, ?, ?, ?)',
                         (login, hashed_password, 'фулбади', machine_str))
            conn.commit()
            user_id = conn.execute('SELECT last_insert_rowid()').fetchone()[0]
        except sqlite3.IntegrityError:
            conn.close()
            return {'message': 'Login already exists'}, 400

        conn.close()
        return {'message': 'User registered successfully', 'id': user_id}, 201


class UpdateUser(Resource):
    def put(self, user_id):
        data = request.get_json()
        new_type = data.get('type')
        new_machines = data.get('machines')

        if not new_type or new_machines is None:
            return {'message': 'type and machines are required'}, 400

        conn = get_db_connection()
        user = conn.execute('SELECT * FROM users WHERE id = ?', (user_id,)).fetchone()
        if not user:
            conn.close()
            return {'message': 'User not found'}, 404

        conn.execute('UPDATE users SET type = ?, machines = ? WHERE id = ?', (new_type, new_machines, user_id))
        conn.commit()
        conn.close()
        return {'message': 'User updated successfully'}


class GenerateWorkout(Resource):
    def post(self):
        data = request.get_json()
        workout_type = data.get('type')
        machines = data.get('machines', '')
        muscles = data.get('muscles', []) if workout_type == 'сплит' else []

        if workout_type not in ['фулбади', 'сплит']:
            return {'message': 'Invalid workout type'}, 400

        machine_ids = [int(m) for m in machines.split(',') if m.strip().isdigit()]
        conn = get_db_connection()

        # Игнорируем "Кардио"
        all_muscle_groups = ['Ноги', 'Спина', 'Грудь', 'Бицепс', 'Трицепс', 'Плечи', 'Предплечья', 'Пресс', 'Трапеции']
        selected_muscles = all_muscle_groups if workout_type == 'фулбади' else [m for m in muscles if
                                                                                m in all_muscle_groups]

        workout = []

        for muscle in selected_muscles:
            if workout_type == 'фулбади':
                limit = 2
            else:
                base = len(selected_muscles) // 9
                limit = max(1, base)
                if len(selected_muscles) == 1:
                    limit = max(1, limit - 2)
                elif len(selected_muscles) == 9:
                    limit += 1

            # Получить упражнения с подходящими тренажерами или free = 1
            query = '''
            SELECT * FROM exercises 
            WHERE description = ? AND (free = 1 OR machine_id IN ({seq}))
            '''.replace('{seq}', ','.join(['?'] * len(machine_ids))) if machine_ids else '''
            SELECT * FROM exercises 
            WHERE description = ? AND free = 1
            '''

            params = [muscle] + machine_ids if machine_ids else [muscle]
            exercises = conn.execute(query, params).fetchall()
            selected = random.sample(exercises, min(len(exercises), limit))
            workout.extend(
                [{'name': e['name'], 'technique': e['technique'], 'muscle': e['description']} for e in selected])

        conn.close()
        return {'workout': workout}, 200


api.add_resource(Users, '/api/users')
api.add_resource(UserByID, '/api/users/<int:user_id>')
api.add_resource(RegisterUser, '/api/register')
api.add_resource(UpdateUser, '/api/users/<int:user_id>/update')
api.add_resource(GenerateWorkout, '/api/generate')

if __name__ == '__main__':
    app.run(debug=True)
