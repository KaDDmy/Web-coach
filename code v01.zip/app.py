from flask import Flask, render_template, request, redirect, session, url_for
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash
import random

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Секретный ключ для сессий


def get_db_connection():
    conn = sqlite3.connect('db.db')
    conn.row_factory = sqlite3.Row
    return conn


@app.route('/')
def index():
    return render_template('index.html', user=session.get('user'))


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        login = request.form['login']
        password = generate_password_hash(request.form['password'])
        conn = get_db_connection()

        # Получаем все id тренажеров
        machine_ids = conn.execute('SELECT id FROM machines').fetchall()
        machine_ids = [str(m['id']) for m in machine_ids]
        machines_string = ','.join(machine_ids)

        try:
            # Добавляем пользователя с заполнением поля machines и типа тренировки (по умолчанию "фулбади")
            conn.execute('INSERT INTO users (login, password, type, machines) VALUES (?, ?, ?, ?)',
                         (login, password, 'фулбади', machines_string))
            conn.commit()
        except sqlite3.IntegrityError:
            conn.close()
            return 'Login already taken!'

        conn.close()
        return redirect('/login')
    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        login = request.form['login']
        password = request.form['password']
        conn = get_db_connection()
        user = conn.execute('SELECT * FROM users WHERE login = ?', (login,)).fetchone()
        conn.close()
        if user and check_password_hash(user['password'], password):
            session['user'] = dict(user)
            return redirect('/')
        else:
            return 'Invalid login or password!'
    return render_template('login.html')


@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect('/')


@app.route('/profile', methods=['GET', 'POST'])
def profile():
    if 'user' not in session:
        return redirect('/login')

    conn = get_db_connection()
    machines = conn.execute('SELECT * FROM machines').fetchall()

    if request.method == 'POST':
        workout_type = request.form['type']
        selected_machines = request.form.getlist('machines')
        machines_str = ','.join(selected_machines)

        conn.execute('UPDATE users SET type = ?, machines = ? WHERE id = ?',
                     (workout_type, machines_str, session['user']['id']))
        conn.commit()

        # Получить обновлённые данные пользователя
        updated_user = conn.execute('SELECT * FROM users WHERE id = ?', (session['user']['id'],)).fetchone()
        session['user'] = dict(updated_user)

    conn.close()
    return render_template('profile.html', user=session['user'], machines=machines)


@app.route('/generate', methods=['GET', 'POST'])
def generate():
    if 'user' not in session:
        return redirect('/login')

    conn = get_db_connection()
    machines_str = session['user'].get('machines', '')
    machines = [m.strip() for m in machines_str.split(',') if m.strip().isdigit()]
    user_type = session['user'].get('type')
    muscle_groups = ['Ноги', 'Спина', 'Грудь', 'Бицепс', 'Трицепс', 'Плечи', 'Предплечья', 'Пресс', 'Трапеции']

    def get_exercises_for_muscle(muscle, limit):
        if machines:
            placeholders = ','.join(['?'] * len(machines))
            query = f'''
                SELECT * FROM exercises
                WHERE description = ? AND (free = 1 OR machine_id IN ({placeholders}))
            '''
            params = [muscle] + machines
        else:
            query = '''
                SELECT * FROM exercises
                WHERE description = ? AND free = 1
            '''
            params = [muscle]

        results = conn.execute(query, params).fetchall()
        return random.sample(results, min(len(results), limit)) if results else []

    if request.method == 'POST':
        exercises = []

        if user_type == 'фулбади':
            for muscle in muscle_groups:
                exercises += get_exercises_for_muscle(muscle, 2)

        elif user_type == 'сплит':
            selected_muscles = [key for key in request.form.keys() if key in muscle_groups and request.form.get(key) == 'on']
            count = len(selected_muscles)

            if count == 0:
                conn.close()
                return render_template('generate.html', exercises=[], user=session.get('user'), message="Выберите хотя бы одну группу мышц.")

            base_limit = max(int(9 / count), 1)
            if count == 1:
                base_limit = max(base_limit - 2, 1)
            elif count > 4:
                base_limit += 1

            for muscle in selected_muscles:
                exercises += get_exercises_for_muscle(muscle, base_limit)

        conn.close()

        for i in range(len(exercises)):
            exercises[i] = dict(exercises[i])
            exercises[i]['name'] = f"{exercises[i]['name']} ({exercises[i]['technique']})"

        return render_template('generate.html', exercises=exercises, user=session.get('user'))

    if user_type == 'сплит':
        return render_template('difficulty.html', user=session.get('user'), muscle_groups=muscle_groups)
    else:
        exercises = []
        for muscle in muscle_groups:
            exercises += get_exercises_for_muscle(muscle, 2)

        conn.close()

        for i in range(len(exercises)):
            exercises[i] = dict(exercises[i])
            exercises[i]['name'] = f"{exercises[i]['name']} ({exercises[i]['technique']})"

        return render_template('generate.html', exercises=exercises, user=session.get('user'))


if __name__ == '__main__':
    app.run(debug=True)