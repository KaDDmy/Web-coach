from requests import get, post, put

# 1. Получить всех пользователей
resp = get('http://localhost:5000/api/users')
print(resp.status_code, resp.json(), '\n')

# 2. Получить пользователя по ID = 1
resp = get('http://localhost:5000/api/users/1')
print(resp.status_code, resp.json(), '\n')

# 3. Зарегистрировать нового пользователя
resp = post('http://localhost:5000/api/register', json={
    'login': 'testuser4',
    'password': 'password'
})
print(resp.status_code, resp.json(), '\n')

# 4. Обновить тип тренировки и тренажёры пользователя
user_id = resp.json().get('id')  # id нового пользователя
if user_id:
    resp = put(f'http://localhost:5000/api/users/{user_id}/update', json={
        'type': 'сплит',
        'machines': '1,3,5,7,9'
    })
    print(resp.status_code, resp.json(), '\n')
