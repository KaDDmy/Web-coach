from requests import get, post, put

# 1. Получить всех пользователей
resp = get('http://localhost:5000/api/users')
print(resp.status_code, resp.json(), '\n')

# 2. Получить пользователя по ID = 1
resp = get('http://localhost:5000/api/users/1')
print(resp.status_code, resp.json(), '\n')

# 3. Зарегистрировать нового пользователя
resp = post('http://localhost:5000/api/register', json={
    'login': 'testuser5',
    'password': '12345'
})
print(resp.status_code, resp.json(), '\n')

# 4. Обновить тип тренировки и тренажёры пользователя
user_id = resp.json().get('id')  # id нового пользователя
if user_id:
    resp = put(f'http://localhost:5000/api/users/{user_id}/update', json={
        'type': 'сплит',
        'machines': '1,3,5,7,9'
    })
    print(resp.status_code, resp.json(), '\n')

# 5. Сгенерировать тренировку фулбади
response = post('http://localhost:5000/api/generate', json={
    "type": "фулбади",
    "machines": "1,2,3"
})
for ex in response.json().get("workout", []):
    print(f"- {ex['muscle']}: {ex['name']} ({ex['technique']})")

# 6. Сгенерировать тренировку сплит
response = post('http://localhost:5000/api/generate', json={
    "type": "сплит",
    "machines": "1,2,3,4",
    "muscles": ["Грудь", "Спина", "Пресс"]
})
for ex in response.json().get("workout", []):
    print(f"- {ex['muscle']}: {ex['name']} ({ex['technique']})")
